//
//  recipeList.swift
//  PassingData
//
//  Created by Panther on 2020/07/24.
//  Copyright © 2020 Panther. All rights reserved.
//

import Foundation


//class recipeList {
    
    

    //var country : String
   // var farm : String
   // var variety : String
    
   // init(country: String, farm: String, variety: String) {
        //self.country = country
        //self.farm = farm
        //self.variety = variety
        
    //}

    
    
    //static var dummyRecipeList = [
    
        //recipeList(country: "Costa Rica", farm: "Don Caiyto", variety: "Typica")

    //]
    
    
//}
